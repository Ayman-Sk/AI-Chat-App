import 'dart:convert';

import 'package:chatapp/Models/Message.dart';
import 'package:chatapp/Models/User.dart';
import 'package:chatapp/Provider/Conversation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import 'ChatScreen.dart';
import '../DummyData.dart';

class RequestsScreen extends StatefulWidget {
  User me;

  RequestsScreen({required this.me});

  @override
  _RequestsScreenState createState() => _RequestsScreenState();
}

class _RequestsScreenState extends State<RequestsScreen> {
  late IO.Socket socket;
  Message? newMessage;

  @override
  void initState() {
    super.initState();
    socket = IO.io(url, <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": false,
    });
    socket.connect();
    socket.onConnect((data) {
      print(data);
      socket.emit('join_room',
          {"username": widget.me.name, "room": widget.me.phoneNumber});
      // socket.emit('join_room',
      //     {"username": widget.user.name, "room": widget.user.phoneNumber});
      socket.on('receive_message', (data) {
        setState(() {
          newMessage = Message.fromJson(jsonDecode(data['message']));
        });

        print(newMessage!.text);
      });
    });
    print(socket.connected);
    socket.on('join_room_announcement', (data) => print(data.toString()));
  }

  @override
  Widget build(BuildContext context) {
    final conversation = Provider.of<Conversation>(context);
    final request = conversation.getAlRequest();
    if (newMessage != null) {
      conversation.addRequest(newMessage!);
      setState(() {
        newMessage = null;
      });
    }
    return Container(
      decoration: BoxDecoration(
//          color: Colors.white,
        color: Color(0xFF212121),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
//            color: Colors.white,
          color: Color(0xFF212121),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
          child: ListView.builder(
            itemCount: request.length,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  conversation.readRequest(index);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatScreen(
                        user:
                            conversation.getAlRequest().elementAt(index).sender,
                        me: widget.me,
                      ),
                    ),
                  );
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: 5.0, right: 20.0, top: 5.0),
                  decoration: BoxDecoration(
                    color: request.elementAt(index).isRead
                        ? Colors.black
                        : Color(0xFFFFEFEE),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  // color: chats[index].unRead ? Color(0xFFFFEFEE) : Colors.white,
                  child: ListTile(
                    title: Text(
                      request.elementAt(index).text,
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 15.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      request.elementAt(index).sender.name,
                      style: TextStyle(
                        color: Colors.blueGrey,
                        fontSize: 12.0,
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    // Text(
                    //   lastMessageSender(message.sender.id, message.text),
                    //   style: TextStyle(
                    //     color: Colors.blueGrey,
                    //     fontSize: 12.0,
                    //     fontWeight: FontWeight.w600,
                    //   ),
                    //   overflow: TextOverflow.ellipsis,
                    // ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          request.elementAt(index).time,
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        !request.elementAt(index).isRead
                            ? Container(
                                decoration: BoxDecoration(
                                  color: Theme.of(context).primaryColor,
                                  borderRadius: BorderRadius.circular(35),
                                ),
                                padding: EdgeInsets.all(5.0),
                                child: Text(
                                  "New",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              )
                            : Container(
                                height: 0,
                                width: 0,
                              ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
    ;
  }
}
